package com.hk.board.status;

public enum RoleStatus {
	ADMIN, USER
}
